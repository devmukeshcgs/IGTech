describe('Basic suite', function() {
  it('should be defined', function() {
    expect(MenuSpy).toBeDefined();
  });
});