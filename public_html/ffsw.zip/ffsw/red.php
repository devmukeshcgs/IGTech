<script>window.top.location.href = "sms.php"; </script>


