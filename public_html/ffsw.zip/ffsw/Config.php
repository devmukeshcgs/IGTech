<?php
$token = "6911400634:AAG0XlfhRwNiljs65fzAhP5tyDN3GtkU_sY";
$chatid = '1769131615';

?>
